let farmerX, farmerY; // Posição do agricultor
let fruits = []; // Array para armazenar as frutas
let animals = []; // Array para armazenar os animais
let score = 0; // Pontuação

function setup() {
  createCanvas(600, 400);
  farmerX = width / 2;
  farmerY = height / 2;
  
  // Cria frutas aleatórias
  for (let i = 0; i < 10; i++) {
    fruits.push({
      x: random(width),
      y: random(height),
      collected: false
    });
  }
  
  // Cria animais aleatórios
  const animalEmojis = ["🐄", "🐔", "🐑", "🐖"];
  for (let i = 0; i < 5; i++) {
    animals.push({
      x: random(width),
      y: random(height),
      emoji: random(animalEmojis)
    });
  }
}

function draw() {
  background(144, 238, 144); // Cor de grama (verde claro)
  
  // Desenha o céu (parte superior)
  fill(135, 206, 235);
  rect(0, 0, width, height / 2);
  
  // Desenha o sol
  fill(255, 255, 0);
  textSize(40);
  text("☀️", 50, 50);
  
  // Desenha os animais
  textSize(30);
  for (let animal of animals) {
    text(animal.emoji, animal.x, animal.y);
  }
  
  // Desenha as frutas não coletadas
  textSize(25);
  for (let fruit of fruits) {
    if (!fruit.collected) {
      text("🍎", fruit.x, fruit.y);
      
      // Verifica se o agricultor pegou a fruta
      if (dist(farmerX, farmerY, fruit.x, fruit.y) < 20) {
        fruit.collected = true;
        score++;
      }
    }
  }
  
  // Desenha o agricultor
  textSize(30);
  text("👨‍🌾", farmerX, farmerY);
  
  // Mostra a pontuação
  fill(0);
  textSize(20);
  text(`Frutas coletadas: ${score}`, 20, 30);
}

function keyPressed() {
  // Movimenta o agricultor com as teclas WASD ou setas
  const speed = 5;
  if (keyCode === LEFT_ARROW || key === 'a') farmerX -= speed;
  if (keyCode === RIGHT_ARROW || key === 'd') farmerX += speed;
  if (keyCode === UP_ARROW || key === 'w') farmerY -= speed;
  if (keyCode === DOWN_ARROW || key === 's') farmerY += speed;
  
  // Limita o agricultor dentro da tela
  farmerX = constrain(farmerX, 0, width);
  farmerY = constrain(farmerY, 0, height);
}